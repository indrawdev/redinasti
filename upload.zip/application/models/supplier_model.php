<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Supplier Model Class
 * @author ivan lubis
 * @version 2.1
 * @category Model
 * @desc supplier model
 * 
 */
class Supplier_model extends CI_Model
{
    
    /**
     * Constructor 
     * @desc to load extends
     */
    function __construct()
    {
        parent::__construct();
    }
    
    /**
     * insert new record supplier
     * @param array $post
     * @return boolean last id or false
     */
    function InsertNewRecord($post) {
        $this->db->insert('supplier',$post);
        $last_id = $this->db->insert_id();
        return $last_id;
    }
    
    /**
     * update supplier record
     * @param int $id
     * @param array $post
     */
    function UpdateRecord($id,$post) {
        $this->db->where('id_supplier',$id);
        $this->db->update('supplier',$post);
    }
    
    /**
     * get supplier detail
     * @param int $id
     * @return array $data
     */
    function getSupplier($id) {
        $data = $this->db
            ->where('id_supplier',$id)
            ->where('is_delete',0)
            ->limit(1)
            ->get('supplier')
            ->row_array();
        return $data;
    }
    
    /**
     * delete record
     * @param int $id
     */
    function DeleteRecord($id) {
        $this->db->where('id_supplier',$id);
        $this->db->update('supplier',array('is_delete'=>1));
    }

}

/* End of file supplier_model.php */
/* Location: ./application/model/supplier_model.php */

