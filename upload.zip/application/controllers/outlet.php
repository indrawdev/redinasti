<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Outlet Class
 * @author ivan lubis
 * @version 2.1
 * @category Controller
 * @desc Outlet Controller
 * 
 */
class Outlet extends CI_Controller
{
    //private $error = array();
    private $error = '';

    public function __construct()
    {
        parent::__construct();
    }
    
    /**
     * Index Page for this controller.
     */
    public function index()
    {
        /**
         * let this function empty just for generating layout
         */
        $this->data['add_url'] = site_url('outlet/add');
        $this->data['export_excel_url'] = site_url('outlet/export_excel');
        $this->data['list_data'] = site_url('outlet/list_data');
    }
    
    /**
     * list of data
     */
    public function list_data()
    {
        $alias['search_outlet'] = "a.outlet";
        $alias['search_address'] = "a.address";
        $alias['search_state'] = "a.state";
        $alias['search_country'] = "b.country";
        $query = "
            select 
                a.id_outlet as id, 
                a.id_outlet as idx, 
                a.*,
                b.country as country
            from " . $this->db->dbprefix('outlet') . " a 
            left join " . $this->db->dbprefix('country') . " b on b.id_country = a.id_country
        ";
        $this->data = query_grid($query, $alias);
        $this->data['paging'] = paging($this->data['total']);
    }
    
    /**
     * add page
     */
    public function add()
    {
        $this->load->model('Outlet_model');
        $this->data['form_action'] = site_url('outlet/add');
        $post = array(
            'outlet'=>'',
            //'location'=>'',
            'address'=>'',
            'id_country'=>0,
            'state'=>'',
            'long'=>'',
            'lat'=>'',
            'embed_link'=>'',
        );
        $this->data['countries'] = $this->Outlet_model->getCountry();
        if ($this->input->post() && $this->validateForm()) {
            $post = purify($this->input->post());
            $data_post = array(
                'id_country' => (int)$post['id_country'],
                'outlet' => $post['outlet'],
                //'location' => $post['location'],
                'address' => $post['address'],
                'state' => $post['state'],
                'long' => $post['long'],
                'lat' => $post['lat'],
                'embed_link' => $post['embed_link'],
            );
            
            // insert data
            $last_id = $this->Outlet_model->InsertRecord($data_post);
            if ($last_id) {
                $this->session->set_flashdata('success_msg', 'Success.<br/>');
            } else {
                $this->session->set_flashdata('tmp_msg', 'Failed.<br/>');
            }
            
            redirect('outlet');
        }
        $this->data['post'] = $post;
        if ($this->error) {
            $this->data['message'] = alert_box($this->error,'error');
        }
    }
    
    /**
     * edit page
     */
    public function edit($id=0)
    {
        $id = (int)$id;
        if (!$id) {
            redirect('outlet');
        }
        $this->load->model('Outlet_model');
        $this->data['form_action'] = site_url('outlet/edit/'.$id);
        $detail = $this->Outlet_model->getOutlet($id);
        if (!$detail) {
            redirect('outlet');
        }
        $post = $detail;
        $this->data['countries'] = $this->Outlet_model->getCountry();
        if ($this->input->post() && $this->validateForm($id)) {
            $post = purify($this->input->post());
            $data_post = array(
                'id_country' => (int)$post['id_country'],
                'outlet' => $post['outlet'],
                //'location' => $post['location'],
                'address' => $post['address'],
                'state' => $post['state'],
                'long' => $post['long'],
                'lat' => $post['lat'],
                'embed_link' => $post['embed_link'],
                'modify_date' => date('Y-m-d H:i:s'),
            );
            
            // update data
            $this->Outlet_model->UpdateRecord($id,$data_post);
            $this->session->set_flashdata('success_msg', 'Success.<br/>');
            
            redirect('outlet');
        }
        $this->data['post'] = $post;
        if ($this->error) {
            $this->data['message'] = alert_box($this->error,'error');
        }
    }
    
    /**
     * delete record
     * @param int $id
     */
    public function delete($id=0) {
        $this->load->model('Outlet_model');
        if (is_ajax_requested()) {
            $this->layout = 'none';
            if ($this->input->post()) {
                $id = (int)$this->input->post('iddel');
                if ($id) {
                    $detail = $this->Outlet_model->getOutlet($id);
                    if ($detail) {
                        $this->Outlet_model->DeleteRecord($id);
                        $this->session->set_flashdata('success_msg','Data has been deleted.');
                    } else {
                        $this->session->set_flashdata('message','There is no record in our database.');
                    }
                }
            }
        } else {
            redirect('outlet');
        }
    }
    
    /**
     * validate form
     * @return boolean
     */
    private function validateForm()
    {
        $post = purify($this->input->post());
        $err = '';

        if ($post['outlet'] == '') {
            $err .= 'Please insert Country.<br/>';
        }

        if ($post['outlet'] == '') {
            $err .= 'Please insert Country.<br/>';
        }

        if ($post['address'] == '') {
            $err .= 'Please insert Address.<br/>';
        }
        
        if ($err) {
            $this->error = $err;
            return false;
        } else {
            return true;
        }
    }
    
}
/* End of file outlet.php */
/* Location: ./application/controllers/outlet.php */


