<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Download Class
 * this class is for download management
 * @author ivan lubis
 * @version 2.1
 * @download Controller
 * @desc Download Controller
 */
class Download extends CI_Controller {

    //private $error = array();
    private $error = '';
    
    /**
     * Index Download for this controller.
     */
    public function index() {
        /**
         * let this function empty just for generating layout
         */
        $this->data['add_url'] = site_url('download/add');
        $this->data['list_data'] = site_url('download/list_data');
    }

    /**
     * list of data
     */
    public function list_data() {
        $alias['search_download_name'] = "a.download_name";
        $query = "
            select 
                a.id_download as id, 
                a.id_download as idx, 
                a.*
            from " . $this->db->dbprefix('download') . " a 
            where a.is_delete = 0";
        $this->data = query_grid($query, $alias);
        $this->data['paging'] = paging($this->data['total']);
    }

    /**
     * add new record
     */
    public function add() {
        $this->load->model('Download_model');
        $this->data['form_action'] = site_url('download/add');
        $post = array(
            'download_name' => '',
        );
        if ($this->input->post()) {
            $post = $this->input->post();
            if ($this->validateForm()) {
                $last_id = $this->Download_model->InsertData($post);
                if ($last_id) {
                    $post_image = $_FILES;
                    if ($post_image['download_file']['tmp_name']) {
                        $filename = 'pri_' . url_title($post['download_name'],'-',TRUE) . md5plus($last_id);
                        $picture_db = file_copy_to_folder($post_image['download_file'], IMG_UPLOAD_DIR . 'download/', $filename);

                        $this->Download_model->UpdateData($last_id, array('download_file' => $picture_db));
                    }
                    $this->session->set_flashdata('success_msg', 'Succeed.');
                } else {
                    $this->session->set_flashdata('tmp_msg', 'Failed.');
                }
                redirect('download');
            }
        }
        $this->data['post'] = $post;
        if ($this->error) {
            $this->data['err_message'] = alert_box($this->error, 'error');
        }
    }

    /**
     * edit new record
     */
    public function edit($id = 0) {
        $this->load->model('Download_model');
        $this->data['form_action'] = site_url('download/edit/' . $id);
        $id = (int) $id;
        if (!$id) {
            redirect('download');
        }
        $detail = $this->Download_model->getDownload($id);
        $post = $detail;
        if ($this->input->post()) {
            $post = $this->input->post();
            if ($this->validateForm($id)) {
                $this->Download_model->UpdateData($id, $post);
                $post_image = $_FILES;
                if ($post_image['download_file']['tmp_name']) {
                    if ($detail['download_file'] != '' && file_exists(IMG_UPLOAD_DIR . 'download/' . $detail['download_file'])) {
                        unlink(IMG_UPLOAD_DIR . 'download/' . $detail['primary_image']);
                    }
                    $filename = 'pri_' . url_title($post['download_name'],'-',TRUE) . md5plus($id);
                    $picture_db = file_copy_to_folder($post_image['download_file'], IMG_UPLOAD_DIR . 'download/', $filename);

                    $this->Download_model->UpdateData($id, array('download_file' => $picture_db));
                }
                $this->session->set_flashdata('success_msg', 'Succeed.');

                redirect('download');
            }
        }
        $this->data['post'] = $post;
        if ($this->error) {
            $this->data['message'] = alert_box($this->error, 'error');
        }
    }
    
    /**
     * delete record
     */
    public function delete() {
        $this->load->model('Download_model');
        if (is_ajax_requested()) {
            $this->layout = 'none';
            if ($this->input->post()) {
                $id = (int) $this->input->post('iddel');
                if ($id) {
                    $detail = $this->Download_model->getDownload($id);
                    if ($detail) {
                        $this->Download_model->DeleteRecord($id);
                        $this->session->set_flashdata('success_msg', 'Data has been deleted.');
                    } else {
                        $this->session->set_flashdata('message', 'There is no record in our database.');
                    }
                }
            }
        } else {
            redirect('download');
        }
    }
    
    /**
     * form validation
     * @param int $id
     * @return boolean true/false
     */
    private function validateForm($id = 0) {
        $id = (int) $id;
        $this->load->model('Download_model');
        $post = $this->input->post();
        $err = '';
        if ($post['download_name'] == '') {
            $err .= 'Please insert Title.<br/>';
        }
        $post_image = $_FILES;
        if ($id) {
            if (!empty($post_image['download_file']['tmp_name'])) {
                $check_file = validateFile('download_file');
                if (!empty($check_file)) {
                    $err .= $check_file . '<br/>';
                }
            }
        } else {
            if (empty($post_image['download_file']['tmp_name'])) {
                $err .= 'Please input file.<br/>';
            } else {
                $check_file = validateFile('download_file');
                if (!empty($check_file)) {
                    $err .= $check_file . '<br/>';
                }
                
            }
        }

        if ($err) {
            $this->error = $err;
            return false;
        } else {
            return true;
        }
    }

}

/* End of file download.php */
/* Location: ./application/controllers/download.php */