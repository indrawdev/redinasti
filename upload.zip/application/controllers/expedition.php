<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
/**
 * Expedition Class
 * this class is for expedition management
 * @author ivan lubis
 * @version 2.1
 * @category Controller
 * @desc Expedition Controller
 */
class Expedition extends CI_Controller
{
    //private $error = array();
    private $error = '';

    /**
     * Index Expedition for this controller.
     */
    public function index()
    {
        /**
         * let this function empty just for generating layout
         */
        $this->data['add_url'] = site_url('expedition/add');
        $this->data['export_excel_url'] = site_url('expedition/export_excel');
        $this->data['list_data'] = site_url('expedition/list_data');
    }
    
    /**
     * list of data
     */
    public function list_data()
    {
        $alias['search_create_date'] = "DATE_FORMAT(CURRENT_TIMESTAMP, '%d  %b  %Y %H:%i:%S')";
        $alias['search_title'] = "b.title";
        $alias['search_status_text'] = "d.status_text";
        $query = "
            select 
                a.id_expedition as id, 
                a.id_expedition as idx, 
                DATE_FORMAT(CURRENT_TIMESTAMP, '%d  %b  %Y %H:%i:%S') as create_date,
                a.*,
                b.title,
                c.locale,
                d.status_text
            from " . $this->db->dbprefix('expeditions') . " a 
            left join " . $this->db->dbprefix('expeditions_detail') . " b on b.id_expedition=a.id_expedition
            left join ".$this->db->dbprefix('localization')." c on c.id_localization=b.id_localization
            left join ".$this->db->dbprefix('status')." d on d.id_status=a.id_status
            where a.is_delete = 0 and c.locale_status=1 ";
        $group_by = "a.id_expedition";
        $this->data = query_grid($query, $alias, $group_by);
        $this->data['paging'] = paging($this->data['total']);
    }
    
    /**
     * add new record
     */
    public function add()
    {
        $this->load->model('Expedition_model');
        $this->data['form_action'] = site_url('expedition/add');
        $post = array(
            //'alias'=>'',
            'uri_path'=>'',
            'publish_date'=>date('Y-m-d'),
            'id_status'=>'',
            'primary_image'=>'',
            'thumbnail_image'=>'',
        );
        $this->data['status_list'] = $this->Expedition_model->getStatus();
        $this->data['locales'] = $this->Expedition_model->getLocale();
        foreach($this->data['locales'] as $locale) {
            $post['content_locale'][$locale['id_localization']] = array(
                'title'=>'',
                'teaser'=>'',
                'description'=>'',
            );
        }
        if ($this->input->post()) {
            $post = $this->input->post();
            if ($this->validateForm()) {
                $post['uri_path'] = url_title($post['uri_path'], '-', true);
                $last_id = $this->Expedition_model->InsertNewRecord($post);
                if ($last_id) {
                    $post_image = $_FILES;
                    if ($post_image['primary_image']['tmp_name']) {
                        $filename = 'pri_'.$post['uri_path'].md5plus($last_id);
                        $picture_db = file_copy_to_folder($post_image['primary_image'], IMG_UPLOAD_DIR.'expedition/', $filename);
                        copy_image_resize_to_folder(IMG_UPLOAD_DIR.'expedition/'.$picture_db, IMG_UPLOAD_DIR.'expedition/', 'tmb_'.$filename, IMG_THUMB_WIDTH, IMG_THUMB_HEIGHT);
                        copy_image_resize_to_folder(IMG_UPLOAD_DIR.'expedition/'.$picture_db, IMG_UPLOAD_DIR.'expedition/', 'sml_'.$filename, IMG_SMALL_WIDTH, IMG_SMALL_HEIGHT);
                        
                        $this->Expedition_model->UpdateData($last_id,array('primary_image'=>$picture_db));
                    }
                    if ($post_image['thumbnail_image']['tmp_name']) {
                        $filename = 'thumb_'.$post['uri_path'].'_'.md5plus($last_id);
                        $picture_db = file_copy_to_folder($post_image['thumbnail_image'], IMG_UPLOAD_DIR.'expedition/', $filename);
                        copy_image_resize_to_folder(IMG_UPLOAD_DIR.'expedition/'.$picture_db, IMG_UPLOAD_DIR.'expedition/', 'tmb_'.$filename, IMG_THUMB_WIDTH, IMG_THUMB_HEIGHT);
                        copy_image_resize_to_folder(IMG_UPLOAD_DIR.'expedition/'.$picture_db, IMG_UPLOAD_DIR.'expedition/', 'sml_'.$filename, IMG_SMALL_WIDTH, IMG_SMALL_HEIGHT);
                        
                        $this->Expedition_model->UpdateData($last_id,array('thumbnail_image'=>$picture_db));
                    }
                    $this->session->set_flashdata('success_msg','Succeed.');
                } else {
                    $this->session->set_flashdata('tmp_msg','Failed.');
                }
                redirect('expedition');
            }
        }
        $this->data['post'] = $post;
        if ($this->error) {
            $this->data['message'] = alert_box($this->error,'error');
        }
    }
    
    /**
     * edit new record
     */
    public function edit($id=0)
    {
        $this->load->model('Expedition_model');
        $this->data['form_action'] = site_url('expedition/edit/'.$id);
        $id = (int)$id;
        if (!$id) {
            redirect('expedition');
        }
        $this->data['status_list'] = $this->Expedition_model->getStatus();
        $this->data['locales'] = $this->Expedition_model->getLocale();
        $detail = $this->Expedition_model->getExpedition($id);
        $post = $detail;
        if ($this->input->post()) {
            $post = $this->input->post();
            if ($this->validateForm($id)) {
                $post['uri_path'] = url_title($post['uri_path'], '-', true);
                $this->Expedition_model->UpdateRecord($id,$post);
                $post_image = $_FILES;
                if ($post_image['primary_image']['tmp_name']) {
                    if ($detail['primary_image'] != '' && file_exists(IMG_UPLOAD_DIR.'expedition/'.$detail['primary_image'])) {
                        unlink(IMG_UPLOAD_DIR.'expedition/'.$detail['primary_image']);
                        unlink(IMG_UPLOAD_DIR.'expedition/tmb_'.$detail['primary_image']);
                        unlink(IMG_UPLOAD_DIR.'expedition/sml_'.$detail['primary_image']);
                    }
                    $filename = 'pri_'.$post['uri_path'].md5plus($id);
                    $picture_db = file_copy_to_folder($post_image['primary_image'], IMG_UPLOAD_DIR.'expedition/', $filename);
                    copy_image_resize_to_folder(IMG_UPLOAD_DIR.'expedition/'.$picture_db, IMG_UPLOAD_DIR.'expedition/', 'tmb_'.$filename, IMG_THUMB_WIDTH, IMG_THUMB_HEIGHT);
                    copy_image_resize_to_folder(IMG_UPLOAD_DIR.'expedition/'.$picture_db, IMG_UPLOAD_DIR.'expedition/', 'sml_'.$filename, IMG_SMALL_WIDTH, IMG_SMALL_HEIGHT);

                    $this->Expedition_model->UpdateData($id,array('primary_image'=>$picture_db));
                }
                if ($post_image['thumbnail_image']['tmp_name']) {
                    if ($detail['thumbnail_image'] != '' && file_exists(IMG_UPLOAD_DIR.'expedition/'.$detail['thumbnail_image'])) {
                        unlink(IMG_UPLOAD_DIR.'expedition/'.$detail['thumbnail_image']);
                        unlink(IMG_UPLOAD_DIR.'expedition/tmb_'.$detail['thumbnail_image']);
                        unlink(IMG_UPLOAD_DIR.'expedition/sml_'.$detail['thumbnail_image']);
                    }
                    $filename = 'thumb_'.$post['uri_path'].'_'.md5plus($id);
                    $picture_db = file_copy_to_folder($post_image['thumbnail_image'], IMG_UPLOAD_DIR.'expedition/', $filename);
                    copy_image_resize_to_folder(IMG_UPLOAD_DIR.'expedition/'.$picture_db, IMG_UPLOAD_DIR.'expedition/', 'tmb_'.$filename, IMG_THUMB_WIDTH, IMG_THUMB_HEIGHT);
                    copy_image_resize_to_folder(IMG_UPLOAD_DIR.'expedition/'.$picture_db, IMG_UPLOAD_DIR.'expedition/', 'sml_'.$filename, IMG_SMALL_WIDTH, IMG_SMALL_HEIGHT);
                    
                    $this->Expedition_model->UpdateData($id,array('thumbnail_image'=>$picture_db));
                }
                $this->session->set_flashdata('success_msg','Succeed.');
                
                redirect('expedition');
            }
        }
        $this->data['post'] = $post;
        if ($this->error) {
            $this->data['message'] = alert_box($this->error,'error');
        }
    }
    
    /**
     * gallery page
     * @param int $id
     */
    public function gallery($id=0) {
        $this->load->model('Expedition_model');
        $this->data['form_action'] = site_url('expedition/gallery/'.$id);
        $id = (int)$id;
        if (!$id) {
            redirect('expedition');
        }
        $this->data['cancel_url'] = site_url('expedition');
        $this->data['list_data'] = site_url('expedition/list_gallery/'.$id);
        $detail = $this->Expedition_model->getExpedition($id);
        $post = $detail;
        $this->data['locales'] = $this->Expedition_model->getLocale();
        foreach($this->data['locales'] as $locale) {
            $post['content_locale'][$locale['id_localization']] = array(
                'caption'=>'',
            );
        }
        if ($this->input->post()) {
            $post = $this->input->post();
            if ($this->validateFormGallery($id)) {
                $uri_path = $detail['uri_path'];
                $post_image = $_FILES;
                if ($post_image['image']['tmp_name']) {
                    $total_gallery = $this->Expedition_model->countGallery($id);
                    $filename = 'gal_'.($total_gallery+1).'_'.$uri_path.md5plus($id);
                    $picture_db = file_copy_to_folder($post_image['image'], IMG_UPLOAD_DIR.'expedition/', $filename);
                    copy_image_resize_to_folder(IMG_UPLOAD_DIR.'expedition/'.$picture_db, IMG_UPLOAD_DIR.'expedition/', 'tmb_'.$filename, IMG_THUMB_WIDTH, IMG_THUMB_HEIGHT);
                    copy_image_resize_to_folder(IMG_UPLOAD_DIR.'expedition/'.$picture_db, IMG_UPLOAD_DIR.'expedition/', 'sml_'.$filename, IMG_SMALL_WIDTH, IMG_SMALL_HEIGHT);
                    $post['id_expedition'] = $id;
                    $post['image'] = $picture_db;
                    $id_insert = $this->Expedition_model->InsertDataImage($post);
                    if ($id_insert) {
                        $this->session->set_flashdata('success_msg','Succeed.');
                    } else {
                        $this->session->set_flashdata('tmp_msg','Failed.');
                    }
                }
                redirect('expedition/gallery/'.$id);
            }
        }
        $this->data['post'] = $post;
        if ($this->error) {
            $this->data['message'] = alert_box($this->error,'error');
        }
    }
    
    /**
     * list of gallery
     */
    public function list_gallery($id=0)
    {
        $alias = array();
        $query = "
            select 
                a.id_expedition_image as id, 
                a.id_expedition_image as idx, 
                DATE_FORMAT(CURRENT_TIMESTAMP, '%d  %b  %Y %H:%i:%S') as create_date,
                a.*,
                b.caption,
                c.locale
            from " . $this->db->dbprefix('expeditions_image') . " a 
            left join " . $this->db->dbprefix('expeditions_image_caption') . " b on b.id_expedition_image=a.id_expedition_image 
            left join " . $this->db->dbprefix('localization') . " c on c.id_localization=b.id_localization
            where a.id_expedition='".(int)$id."' and c.locale_status=1
            ";
        $group_by = "a.id_expedition_image";
        $this->data = query_grid($query, $alias, $group_by);
        $this->data['paging'] = paging($this->data['total']);
    }
    
    
    /**
     * slideshow page
     * @param int $id
     */
    public function slideshow($id=0) {
        $this->load->model('Expedition_model');
        $this->data['form_action'] = site_url('expedition/slideshow/'.$id);
        $id = (int)$id;
        if (!$id) {
            redirect('expedition');
        }
        $this->data['cancel_url'] = site_url('expedition');
        $this->data['list_data'] = site_url('expedition/list_slideshow/'.$id);
        $detail = $this->Expedition_model->getExpedition($id);
        $post = $detail;
        $this->data['locales'] = $this->Expedition_model->getLocale();
        foreach($this->data['locales'] as $locale) {
            $post['content_locale'][$locale['id_localization']] = array(
                'caption'=>'',
            );
        }
        if ($this->input->post()) {
            $post = $this->input->post();
            if ($this->validateFormGallery($id)) {
                $uri_path = $detail['uri_path'];
                $post_image = $_FILES;
                if ($post_image['image']['tmp_name']) {
                    $total_slideshow = $this->Expedition_model->countSlideshow($id);
                    $filename = 'slid_'.($total_slideshow+1).'_'.$uri_path.md5plus($id);
                    $picture_db = file_copy_to_folder($post_image['image'], IMG_UPLOAD_DIR.'expedition/', $filename);
                    copy_image_resize_to_folder(IMG_UPLOAD_DIR.'expedition/'.$picture_db, IMG_UPLOAD_DIR.'expedition/', 'tmb_'.$filename, IMG_THUMB_WIDTH, IMG_THUMB_HEIGHT);
                    copy_image_resize_to_folder(IMG_UPLOAD_DIR.'expedition/'.$picture_db, IMG_UPLOAD_DIR.'expedition/', 'sml_'.$filename, IMG_SMALL_WIDTH, IMG_SMALL_HEIGHT);
                    $post['id_expedition'] = $id;
                    $post['image'] = $picture_db;
                    $id_insert = $this->Expedition_model->InsertDataSlideshow($post);
                    if ($id_insert) {
                        $this->session->set_flashdata('success_msg','Succeed.');
                    } else {
                        $this->session->set_flashdata('tmp_msg','Failed.');
                    }
                }
                redirect('expedition/slideshow/'.$id);
            }
        }
        $this->data['post'] = $post;
        if ($this->error) {
            $this->data['message'] = alert_box($this->error,'error');
        }
    }
    
    /**
     * list of slideshow
     */
    public function list_slideshow($id=0)
    {
        $alias = array();
        $query = "
            select 
                a.id_expedition_slideshow as id, 
                a.id_expedition_slideshow as idx, 
                DATE_FORMAT(CURRENT_TIMESTAMP, '%d  %b  %Y %H:%i:%S') as create_date,
                a.*,
                b.caption,
                c.locale
            from " . $this->db->dbprefix('expeditions_slideshow') . " a 
            left join " . $this->db->dbprefix('expeditions_slideshow_caption') . " b on b.id_expedition_slideshow=a.id_expedition_slideshow 
            left join " . $this->db->dbprefix('localization') . " c on c.id_localization=b.id_localization
            where a.id_expedition='".(int)$id."' and c.locale_status=1
            ";
        $group_by = "a.id_expedition_slideshow";
        $this->data = query_grid($query, $alias, $group_by);
        $this->data['paging'] = paging($this->data['total']);
    }
    
    /**
     * delete record
     */
    public function delete() {
        $this->load->model('Expedition_model');
        if (is_ajax_requested()) {
            $this->layout = 'none';
            if ($this->input->post()) {
                $id = (int)$this->input->post('iddel');
                if ($id) {
                    $detail = $this->Expedition_model->getExpedition($id);
                    if ($detail) {
                        $this->Expedition_model->DeleteRecord($id);
                        $this->session->set_flashdata('success_msg','Data has been deleted.');
                    } else {
                        $this->session->set_flashdata('message','There is no record in our database.');
                    }
                }
            }
        } else {
            redirect('expedition');
        }
    }
    
    /**
     * delete gallery record
     */
    public function delete_gallery() {
        $this->load->model('Expedition_model');
        if (is_ajax_requested()) {
            $this->layout = 'none';
            if ($this->input->post()) {
                $id = (int)$this->input->post('iddel');
                if ($id) {
                    $detail = $this->Expedition_model->getExpeditionGallery($id);
                    if ($detail) {
                        $this->Expedition_model->DeleteRecordGallery($id);
                        $this->session->set_flashdata('success_msg','Data has been deleted.');
                    } else {
                        $this->session->set_flashdata('message','There is no record in our database.');
                    }
                }
            }
        } else {
            redirect('expedition');
        }
    }

    /**
     * delete slideshow record
     */
    public function delete_slideshow() {
        $this->load->model('Expedition_model');
        if (is_ajax_requested()) {
            $this->layout = 'none';
            if ($this->input->post()) {
                $id = (int)$this->input->post('iddel');
                if ($id) {
                    $detail = $this->Expedition_model->getExpeditionSlideshow($id);
                    if ($detail) {
                        $this->Expedition_model->DeleteRecordSlideshow($id);
                        $this->session->set_flashdata('success_msg','Data has been deleted.');
                    } else {
                        $this->session->set_flashdata('message','There is no record in our database.');
                    }
                }
            }
        } else {
            redirect('expedition');
        }
    }

    /**
     * form validation
     * @param int $id
     * @return boolean true/false
     */
    private function validateForm($id=0) {
        $id = (int)$id;
        $this->load->model('Expedition_model');
        $locales = $this->Expedition_model->getLocaleDefault();
        $post = $this->input->post();
        $post['uri_path'] = url_title($post['uri_path'], '-', true);
        $err = '';
        /*if ($post['alias'] =='') {
            $err .= 'Please insert Expedition Title.<br/>';
        }*/
        foreach($post['content_locale'] as $row => $val) {
            if ($row == $locales['id_localization'] && $val['title'] == '') {
                $err .= 'Please insert Content Title.<br/>';
            }
        }
        if (empty($post['content_locale']) || count($post['content_locale']) == 0) {
            $err .= 'Please insert Expedition Content.<br/>';
        }
        if ($post['uri_path'] == '') {
            $err .= 'Please insert SEO Link.<br/>';
        } else {
            if (!$this->Expedition_model->check_exists_path($post['uri_path'],$id)) {
                $err .= 'SEO Link already used.<br/>';
            }
        }
        $post_image = $_FILES;
        if (!empty($post_image['primary_image']['tmp_name'])) {
            $check_picture = validatePicture('primary_image');
            if (!empty($check_picture)) {
                $err .= $check_picture.'<br/>';
            }
        }
        if (!empty($post_image['thumbnail_image']['tmp_name'])) {
            $check_picture = validatePicture('thumbnail_image');
            if (!empty($check_picture)) {
                $err .= $check_picture.'<br/>';
            }
        }
        
        if ($err) {
            $this->error = $err;
            return false;
        } else {
            return true;
        }
    }
    
    /**
     * validate gallery form
     * @param int $id
     * @return boolean
     */
    private function validateFormGallery($id=0) {
        $id = (int)$id;
        $post = $this->input->post();
        $post_file = $_FILES;
        $err = '';
        if (!$id) {
            redirect('expedition');
        }
        if ($post_file['image']['tmp_name'] =='') {
            $err .= 'Please insert Image.<br/>';
        } else {
            $check_picture = validatePicture('image');
            if (!empty($check_picture)) {
                $err .= $check_picture.'<br/>';
            }
        }
        
        if ($err) {
            $this->error = $err;
            return false;
        } else {
            return true;
        }
    }

}
/* End of file expedition.php */
/* Location: ./application/controllers/expedition.php */