<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
/**
 * Partner Class
 * this class is for partner management
 * @author ivan lubis
 * @version 2.1
 * @category Controller
 * @desc Partner Controller
 */
class Partner extends CI_Controller
{
    //private $error = array();
    private $error = '';

    /**
     * Index Partner for this controller.
     */
    public function index()
    {
        /**
         * let this function empty just for generating layout
         */
        $this->data['add_url'] = site_url('partner/add');
        $this->data['export_excel_url'] = site_url('partner/export_excel');
        $this->data['list_data'] = site_url('partner/list_data');
    }
    
    /**
     * list of data
     */
    public function list_data()
    {
        $alias['search_create_date'] = "DATE_FORMAT(CURRENT_TIMESTAMP, '%d  %b  %Y %H:%i:%S')";
        $alias['search_title'] = "c.title";
        $alias['search_status_text'] = "b.status_text";
        $query = "
            select 
                a.id_partner as id, 
                a.id_partner as idx, 
                DATE_FORMAT(CURRENT_TIMESTAMP, '%d  %b  %Y %H:%i:%S') as create_date,
                a.*,
                b.status_text,
                d.locale,
                c.title
            from " . $this->db->dbprefix('partners') . " a 
            left join " . $this->db->dbprefix('status') . " b on a.id_status = b.id_status
            left join " . $this->db->dbprefix('partners_detail') . " c on c.id_partner=a.id_partner
            left join ".$this->db->dbprefix('localization')." d on d.id_localization=c.id_localization
            where is_delete = 0 and d.locale_status=1";
        $group_by = "a.id_partner";
        $this->data = query_grid($query, $alias,$group_by);
        $this->data['paging'] = paging($this->data['total']);
    }
    
    /**
     * add new record
     */
    public function add()
    {
        $this->load->model('Partner_model');
        $this->data['form_action'] = site_url('partner/add');
        $post = array(
            //'alias'=>'',
            'uri_path'=>'',
            'publish_date'=>date('Y-m-d'),
            'id_status'=>'',
            'is_featured'=>false,
            'primary_image'=>'',
            'thumbnail_image'=>'',
        );
        $this->data['status_list'] = $this->Partner_model->getStatus();
        $this->data['locales'] = $this->Partner_model->getLocale();
        foreach($this->data['locales'] as $locale) {
            $post['content_locale'][$locale['id_localization']] = array(
                'title'=>'',
                'teaser'=>'',
                'description'=>'',
            );
        }
        if ($this->input->post()) {
            $post = $this->input->post();
            if ($this->validateForm()) {
                $post['uri_path'] = url_title($post['uri_path'], '-', true);
                if (isset($post['is_featured'])) {
                    $post['is_featured'] = 1;
                } else{
                    $post['is_featured'] = 0;
                }
                $last_id = $this->Partner_model->InsertNewRecord($post);
                if ($last_id) {
                    $post_image = $_FILES;
                    if ($post_image['primary_image']['tmp_name']) {
                        $filename = 'pri_'.$post['uri_path'].md5plus($last_id);
                        $picture_db = file_copy_to_folder($post_image['primary_image'], IMG_UPLOAD_DIR.'partner/', $filename);
                        copy_image_resize_to_folder(IMG_UPLOAD_DIR.'partner/'.$picture_db, IMG_UPLOAD_DIR.'partner/', 'tmb_'.$filename, IMG_THUMB_WIDTH, IMG_THUMB_HEIGHT);
                        copy_image_resize_to_folder(IMG_UPLOAD_DIR.'partner/'.$picture_db, IMG_UPLOAD_DIR.'partner/', 'sml_'.$filename, IMG_SMALL_WIDTH, IMG_SMALL_HEIGHT);
                        
                        $this->Partner_model->UpdateData($last_id,array('primary_image'=>$picture_db));
                    }
                    if ($post_image['thumbnail_image']['tmp_name']) {
                        $filename = 'thumb_'.$post['uri_path'].'_'.md5plus($last_id);
                        $picture_db = file_copy_to_folder($post_image['thumbnail_image'], IMG_UPLOAD_DIR.'partner/', $filename);
                        copy_image_resize_to_folder(IMG_UPLOAD_DIR.'partner/'.$picture_db, IMG_UPLOAD_DIR.'partner/', 'tmb_'.$filename, IMG_THUMB_WIDTH, IMG_THUMB_HEIGHT);
                        copy_image_resize_to_folder(IMG_UPLOAD_DIR.'partner/'.$picture_db, IMG_UPLOAD_DIR.'partner/', 'sml_'.$filename, IMG_SMALL_WIDTH, IMG_SMALL_HEIGHT);
                        
                        $this->Partner_model->UpdateData($last_id,array('thumbnail_image'=>$picture_db));
                    }
                    $this->session->set_flashdata('success_msg','Succeed.');
                } else {
                    $this->session->set_flashdata('tmp_msg','Failed.');
                }
                redirect('partner');
            }
        }
        $this->data['post'] = $post;
        if ($this->error) {
            $this->data['message'] = alert_box($this->error,'error');
        }
    }
    
    /**
     * edit new record
     */
    public function edit($id=0)
    {
        $this->load->model('Partner_model');
        $this->data['form_action'] = site_url('partner/edit/'.$id);
        $id = (int)$id;
        if (!$id) {
            redirect('partner');
        }
        $this->data['status_list'] = $this->Partner_model->getStatus();
        $this->data['locales'] = $this->Partner_model->getLocale();
        $detail = $this->Partner_model->getPartner($id);
        $post = $detail;
        if ($this->input->post()) {
            $post = $this->input->post();
            if ($this->validateForm($id)) {
                $post['uri_path'] = url_title($post['uri_path'], '-', true);
                if (isset($post['is_featured'])) {
                    $post['is_featured'] = 1;
                } else{
                    $post['is_featured'] = 0;
                }
                $this->Partner_model->UpdateRecord($id,$post);
                $post_image = $_FILES;
                if ($post_image['primary_image']['tmp_name']) {
                    if ($detail['primary_image'] != '' && file_exists(IMG_UPLOAD_DIR.'partner/'.$detail['primary_image'])) {
                        unlink(IMG_UPLOAD_DIR.'partner/'.$detail['primary_image']);
                        unlink(IMG_UPLOAD_DIR.'partner/tmb_'.$detail['primary_image']);
                        unlink(IMG_UPLOAD_DIR.'partner/sml_'.$detail['primary_image']);
                    }
                    $filename = 'pri_'.$post['uri_path'].md5plus($id);
                    $picture_db = file_copy_to_folder($post_image['primary_image'], IMG_UPLOAD_DIR.'partner/', $filename);
                    copy_image_resize_to_folder(IMG_UPLOAD_DIR.'partner/'.$picture_db, IMG_UPLOAD_DIR.'partner/', 'tmb_'.$filename, IMG_THUMB_WIDTH, IMG_THUMB_HEIGHT);
                    copy_image_resize_to_folder(IMG_UPLOAD_DIR.'partner/'.$picture_db, IMG_UPLOAD_DIR.'partner/', 'sml_'.$filename, IMG_SMALL_WIDTH, IMG_SMALL_HEIGHT);

                    $this->Partner_model->UpdateData($id,array('primary_image'=>$picture_db));
                }
                if ($post_image['thumbnail_image']['tmp_name']) {
                    if ($detail['thumbnail_image'] != '' && file_exists(IMG_UPLOAD_DIR.'partner/'.$detail['thumbnail_image'])) {
                        unlink(IMG_UPLOAD_DIR.'partner/'.$detail['thumbnail_image']);
                        unlink(IMG_UPLOAD_DIR.'partner/tmb_'.$detail['thumbnail_image']);
                        unlink(IMG_UPLOAD_DIR.'partner/sml_'.$detail['thumbnail_image']);
                    }
                    $filename = 'thumb_'.$post['uri_path'].'_'.md5plus($id);
                    $picture_db = file_copy_to_folder($post_image['thumbnail_image'], IMG_UPLOAD_DIR.'partner/', $filename);
                    copy_image_resize_to_folder(IMG_UPLOAD_DIR.'partner/'.$picture_db, IMG_UPLOAD_DIR.'partner/', 'tmb_'.$filename, IMG_THUMB_WIDTH, IMG_THUMB_HEIGHT);
                    copy_image_resize_to_folder(IMG_UPLOAD_DIR.'partner/'.$picture_db, IMG_UPLOAD_DIR.'partner/', 'sml_'.$filename, IMG_SMALL_WIDTH, IMG_SMALL_HEIGHT);
                    
                    $this->Partner_model->UpdateData($id,array('thumbnail_image'=>$picture_db));
                }
                $this->session->set_flashdata('success_msg','Succeed.');
                
                redirect('partner');
            }
        }
        $this->data['post'] = $post;
        if ($this->error) {
            $this->data['message'] = alert_box($this->error,'error');
        }
    }
    
    /**
     * delete record
     */
    public function delete() {
        $this->load->model('Partner_model');
        if (is_ajax_requested()) {
            $this->layout = 'none';
            if ($this->input->post()) {
                $id = (int)$this->input->post('iddel');
                if ($id) {
                    $detail = $this->Partner_model->getPartner($id);
                    if ($detail) {
                        $this->Partner_model->DeleteRecord($id);
                        $this->session->set_flashdata('success_msg','Data has been deleted.');
                    } else {
                        $this->session->set_flashdata('message','There is no record in our database.');
                    }
                }
            }
        } else {
            redirect('partner');
        }
    }

    /**
     * form validation
     * @param int $id
     * @return boolean true/false
     */
    private function validateForm($id=0) {
        $id = (int)$id;
        $this->load->model('Partner_model');
        $locales = $this->Partner_model->getLocaleDefault();
        $post = $this->input->post();
        $post['uri_path'] = url_title($post['uri_path'], '-', true);
        $err = '';
        /*if ($post['alias'] =='') {
            $err .= 'Please insert Partner Title.<br/>';
        }*/
        foreach($post['content_locale'] as $row => $val) {
            if ($row == $locales['id_localization'] && $val['title'] == '') {
                $err .= 'Please insert Content Title.<br/>';
            }
        }
        if ($post['uri_path'] == '') {
            $err .= 'Please insert SEO Link.<br/>';
        } else {
            if (!$this->Partner_model->check_exists_path($post['uri_path'],$id)) {
                $err .= 'SEO Link already used.<br/>';
            }
        }
        $post_image = $_FILES;
        if (!empty($post_image['primary_image']['tmp_name'])) {
            $check_picture = validatePicture('primary_image');
            if (!empty($check_picture)) {
                $err .= $check_picture.'<br/>';
            }
        }
        if (!empty($post_image['thumbnail_image']['tmp_name'])) {
            $check_picture = validatePicture('thumbnail_image');
            if (!empty($check_picture)) {
                $err .= $check_picture.'<br/>';
            }
        }
        
        if ($err) {
            $this->error = $err;
            return false;
        } else {
            return true;
        }
    }

}
/* End of file partner.php */
/* Location: ./application/controllers/partner.php */