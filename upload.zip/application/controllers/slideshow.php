<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Slideshow Class
 * this class is for slideshow management
 * @author ivan lubis
 * @version 2.1
 * @slideshow Controller
 * @desc Slideshow Controller
 */
class Slideshow extends CI_Controller {

    //private $error = array();
    private $error = '';

    /**
     * Index Slideshow for this controller.
     */
    public function index() {
        /**
         * let this function empty just for generating layout
         */
        $this->data['add_url'] = site_url('slideshow/add');
        $this->data['export_excel_url'] = site_url('slideshow/export_excel');
        $this->data['list_data'] = site_url('slideshow/list_data');
    }

    /**
     * list of data
     */
    public function list_data() {
        $alias['search_create_date'] = "DATE_FORMAT(CURRENT_TIMESTAMP, '%d  %b  %Y %H:%i:%S')";
        $alias['search_title'] = "b.title";
        $alias['search_status'] = "d.status_text";
        $query = "
            select 
                a.id_slideshow as id, 
                a.id_slideshow as idx, 
                DATE_FORMAT(CURRENT_TIMESTAMP, '%d  %b  %Y %H:%i:%S') as create_date,
                a.*,
                b.caption,
                c.locale,
                d.status_text
            from " . $this->db->dbprefix('slideshow') . " a 
            left join " . $this->db->dbprefix('slideshow_detail') . " b on b.id_slideshow=a.id_slideshow
            left join " . $this->db->dbprefix('localization') . " c on c.id_localization=b.id_localization
            left join " . $this->db->dbprefix('status') . " d on d.id_status=a.id_status
            where c.locale_status=1";
        $group_by = "a.id_slideshow";
        $this->data = query_grid($query, $alias, $group_by);
        $this->data['paging'] = paging($this->data['total']);
    }

    /**
     * add new record
     */
    public function add() {
        $this->load->model('Slideshow_model');
        $this->data['form_action'] = site_url('slideshow/add');
        $post = array(
            'image' => '',
            'id_status' => '',
            'position'=>($this->Slideshow_model->getMaxPosition()+1),
        );
        $this->data['locales'] = $this->Slideshow_model->getLocale();
        $this->data['status_list'] = $this->Slideshow_model->getStatus();
        foreach ($this->data['locales'] as $locale) {
            $post['content_locale'][$locale['id_localization']] = array(
                'caption' => '',
            );
        }
        if ($this->input->post()) {
            $post = $this->input->post();
            if ($this->validateForm()) {
                $last_id = $this->Slideshow_model->InsertNewRecord($post);
                if ($last_id) {
                    $post_image = $_FILES;
                    if ($post_image['image']['tmp_name']) {
                        $filename = 'pri_slide_' . md5plus($last_id);
                        $picture_db = file_copy_to_folder($post_image['image'], IMG_UPLOAD_DIR . 'slideshow/', $filename);
                        copy_image_resize_to_folder(IMG_UPLOAD_DIR . 'slideshow/' . $picture_db, IMG_UPLOAD_DIR . 'slideshow/', 'tmb_' . $filename, IMG_THUMB_WIDTH, IMG_THUMB_HEIGHT);
                        copy_image_resize_to_folder(IMG_UPLOAD_DIR . 'slideshow/' . $picture_db, IMG_UPLOAD_DIR . 'slideshow/', 'sml_' . $filename, IMG_SMALL_WIDTH, IMG_SMALL_HEIGHT);

                        $this->Slideshow_model->UpdateData($last_id, array('image' => $picture_db));
                    }
                    $this->session->set_flashdata('success_msg', 'Succeed.');
                } else {
                    $this->session->set_flashdata('tmp_msg', 'Failed.');
                }
                redirect('slideshow');
            }
        }
        $this->data['post'] = $post;
        if ($this->error) {
            $this->data['err_message'] = alert_box($this->error, 'error');
        }
    }

    /**
     * edit new record
     */
    public function edit($id = 0) {
        $this->load->model('Slideshow_model');
        $this->data['form_action'] = site_url('slideshow/edit/' . $id);
        $id = (int) $id;
        if (!$id) {
            redirect('slideshow');
        }
        $this->data['locales'] = $this->Slideshow_model->getLocale();
        $this->data['status_list'] = $this->Slideshow_model->getStatus();
        $detail = $this->Slideshow_model->getSlideshow($id);
        $post = $detail;
        if ($this->input->post()) {
            $post = $this->input->post();
            if ($this->validateForm($id)) {
                $this->Slideshow_model->UpdateRecord($id, $post);
                $post_image = $_FILES;
                if ($post_image['image']['tmp_name']) {
                    if ($detail['image'] != '' && file_exists(IMG_UPLOAD_DIR . 'slideshow/' . $detail['image'])) {
                        unlink(IMG_UPLOAD_DIR . 'slideshow/' . $detail['image']);
                        unlink(IMG_UPLOAD_DIR . 'slideshow/tmb_' . $detail['image']);
                        unlink(IMG_UPLOAD_DIR . 'slideshow/sml_' . $detail['image']);
                    }
                    $filename = 'pri_slide_' . md5plus($id);
                    $picture_db = file_copy_to_folder($post_image['image'], IMG_UPLOAD_DIR . 'slideshow/', $filename);
                    copy_image_resize_to_folder(IMG_UPLOAD_DIR . 'slideshow/' . $picture_db, IMG_UPLOAD_DIR . 'slideshow/', 'tmb_' . $filename, IMG_THUMB_WIDTH, IMG_THUMB_HEIGHT);
                    copy_image_resize_to_folder(IMG_UPLOAD_DIR . 'slideshow/' . $picture_db, IMG_UPLOAD_DIR . 'slideshow/', 'sml_' . $filename, IMG_SMALL_WIDTH, IMG_SMALL_HEIGHT);

                    $this->Slideshow_model->UpdateData($id, array('image' => $picture_db));
                }
                $this->session->set_flashdata('success_msg', 'Succeed.');

                redirect('slideshow');
            }
        }
        $this->data['post'] = $post;
        if ($this->error) {
            $this->data['message'] = alert_box($this->error, 'error');
        }
    }
    
    /**
     * insert gallery page
     * @param int $id
     */
    public function tag($id = 0) {
        $this->load->model('Slideshow_model');
        $this->data['form_action'] = site_url('slideshow/insert_tag');
        $this->data['form_delete'] = site_url('slideshow/delete_tag');
        $id = (int) $id;
        if (!$id) {
            redirect('slideshow');
        }
        $this->data['cancel_url'] = site_url('slideshow');
        $detail = $this->Slideshow_model->getTagGallery($id);
        $post = $detail;
        $this->data['post'] = $post;
        if ($this->error) {
            $this->data['message'] = alert_box($this->error, 'error');
        }
    }
    
    /**
     * post form from insert tag
     */
    public function insert_tag() {
        $this->layout='none';
        if (is_ajax_requested()) {
            if ($this->input->post()) {
                $post = $this->input->post();
                $json = array();
                
                $this->load->model('Slideshow_model');
                $last_id = $this->Slideshow_model->InsertNewTag($post);
                if ($last_id) {
                    $json['success'] = alert_box('Insert tag succeed.', 'success');
                    $this->session->set_flashdata('success_msg','Insert tag succeed.');
                    $json['redirect'] = site_url('slideshow/tag/'.$post['id_slideshow']);
                } else {
                    $json['error'] = alert_box('Insert failed.', 'error');
                    $this->session->set_flashdata('tmp_msg','Insert failed.');
                }
                echo json_encode($json);
            }
        }
    }
    
    /**
     * delete tag
     */
    public function delete_tag() {
        $this->layout='none';
        if (is_ajax_requested()) {
            if ($this->input->post()) {
                $post = $this->input->post();
                $json = array();
                
                $this->load->model('Slideshow_model');
                $delete = $this->Slideshow_model->DeleteTag($post['id_slideshow_tag']);
                if ($delete) {
                    $json['success'] = alert_box('Delete tag succeed.', 'success');
                    $this->session->set_flashdata('success_msg','Delete tag succeed.');
                    $json['redirect'] = site_url('slideshow/tag/'.$post['id_slideshow']);
                } else {
                    $json['error'] = alert_box('Delete failed.', 'error');
                    $this->session->set_flashdata('tmp_msg','Delete failed.');
                }
                echo json_encode($json);
            }
        }
    }
    
    /**
     * delete record
     */
    public function delete() {
        $this->load->model('Slideshow_model');
        if (is_ajax_requested()) {
            $this->layout = 'none';
            if ($this->input->post()) {
                $id = (int) $this->input->post('iddel');
                if ($id) {
                    $detail = $this->Slideshow_model->getSlideshow($id);
                    if ($detail) {
                        $this->Slideshow_model->DeleteRecord($id);
                        $this->session->set_flashdata('success_msg', 'Data has been deleted.');
                    } else {
                        $this->session->set_flashdata('message', 'There is no record in our database.');
                    }
                }
            }
        } else {
            redirect('slideshow');
        }
    }
    
    /**
     * form validation
     * @param int $id
     * @return boolean true/false
     */
    private function validateForm($id = 0) {
        $id = (int) $id;
        $post = $this->input->post();
        $err = '';
        
        $post_image = $_FILES;
        if (!empty($post_image['image']['tmp_name'])) {
            $check_picture = validatePicture('image');
            if (!empty($check_picture)) {
                $err .= $check_picture . '<br/>';
            }
        } else {
            if (!$id) {
                $err .= 'Please insert picture.<br/>';
            }
        }

        if ($err) {
            $this->error = $err;
            return false;
        } else {
            return true;
        }
    }

}

/* End of file slideshow.php */
/* Location: ./application/controllers/slideshow.php */