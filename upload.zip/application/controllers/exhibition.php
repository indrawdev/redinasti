<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
/**
 * Exhibition Class
 * this class is for exhibition management
 * @author ivan lubis
 * @version 2.1
 * @category Controller
 * @desc Exhibition Controller
 */
class Exhibition extends CI_Controller
{
    //private $error = array();
    private $error = '';

    /**
     * Index Exhibition for this controller.
     */
    public function index()
    {
        /**
         * let this function empty just for generating layout
         */
        $this->data['add_url'] = site_url('exhibition/add');
        $this->data['export_excel_url'] = site_url('exhibition/export_excel');
        $this->data['list_data'] = site_url('exhibition/list_data');
    }
    
    /**
     * list of data
     */
    public function list_data()
    {
        $alias['search_create_date'] = "DATE_FORMAT(CURRENT_TIMESTAMP, '%d  %b  %Y %H:%i:%S')";
        $alias['search_title'] = "b.title";
        $alias['search_status_text'] = "d.status_text";
        $query = "
            select 
                a.id_exhibition as id, 
                a.id_exhibition as idx, 
                DATE_FORMAT(CURRENT_TIMESTAMP, '%d  %b  %Y %H:%i:%S') as create_date,
                a.*,
                b.title,
                c.locale,
                d.status_text
            from " . $this->db->dbprefix('exhibitions') . " a 
            left join " . $this->db->dbprefix('exhibitions_detail') . " b on b.id_exhibition=a.id_exhibition
            left join ".$this->db->dbprefix('localization')." c on c.id_localization=b.id_localization
            left join ".$this->db->dbprefix('status')." d on d.id_status=a.id_status
            where a.is_delete = 0 and c.locale_status=1 ";
        $group_by = "a.id_exhibition";
        $this->data = query_grid($query, $alias, $group_by);
        $this->data['paging'] = paging($this->data['total']);
    }
    
    /**
     * add new record
     */
    public function add()
    {
        $this->load->model('Exhibition_model');
        $this->data['form_action'] = site_url('exhibition/add');
        $post = array(
            //'alias'=>'',
            'uri_path'=>'',
            'publish_date'=>date('Y-m-d'),
            'id_status'=>'',
            'primary_image'=>'',
            'thumbnail_image'=>'',
        );
        $this->data['status_list'] = $this->Exhibition_model->getStatus();
        $this->data['locales'] = $this->Exhibition_model->getLocale();
        foreach($this->data['locales'] as $locale) {
            $post['content_locale'][$locale['id_localization']] = array(
                'title'=>'',
                'teaser'=>'',
                'description'=>'',
            );
        }
        if ($this->input->post()) {
            $post = $this->input->post();
            if ($this->validateForm()) {
                $post['uri_path'] = url_title($post['uri_path'], '-', true);
                $last_id = $this->Exhibition_model->InsertNewRecord($post);
                if ($last_id) {
                    $post_image = $_FILES;
                    if ($post_image['primary_image']['tmp_name']) {
                        $filename = 'pri_'.$post['uri_path'].md5plus($last_id);
                        $picture_db = file_copy_to_folder($post_image['primary_image'], IMG_UPLOAD_DIR.'exhibition/', $filename);
                        copy_image_resize_to_folder(IMG_UPLOAD_DIR.'exhibition/'.$picture_db, IMG_UPLOAD_DIR.'exhibition/', 'tmb_'.$filename, IMG_THUMB_WIDTH, IMG_THUMB_HEIGHT);
                        copy_image_resize_to_folder(IMG_UPLOAD_DIR.'exhibition/'.$picture_db, IMG_UPLOAD_DIR.'exhibition/', 'sml_'.$filename, IMG_SMALL_WIDTH, IMG_SMALL_HEIGHT);
                        
                        $this->Exhibition_model->UpdateData($last_id,array('primary_image'=>$picture_db));
                    }
                    if ($post_image['thumbnail_image']['tmp_name']) {
                        $filename = 'thumb_'.$post['uri_path'].'_'.md5plus($last_id);
                        $picture_db = file_copy_to_folder($post_image['thumbnail_image'], IMG_UPLOAD_DIR.'exhibition/', $filename);
                        copy_image_resize_to_folder(IMG_UPLOAD_DIR.'exhibition/'.$picture_db, IMG_UPLOAD_DIR.'exhibition/', 'tmb_'.$filename, IMG_THUMB_WIDTH, IMG_THUMB_HEIGHT);
                        copy_image_resize_to_folder(IMG_UPLOAD_DIR.'exhibition/'.$picture_db, IMG_UPLOAD_DIR.'exhibition/', 'sml_'.$filename, IMG_SMALL_WIDTH, IMG_SMALL_HEIGHT);
                        
                        $this->Exhibition_model->UpdateData($last_id,array('thumbnail_image'=>$picture_db));
                    }
                    $this->session->set_flashdata('success_msg','Succeed.');
                } else {
                    $this->session->set_flashdata('tmp_msg','Failed.');
                }
                redirect('exhibition');
            }
        }
        $this->data['post'] = $post;
        if ($this->error) {
            $this->data['message'] = alert_box($this->error,'error');
        }
    }
    
    /**
     * edit new record
     */
    public function edit($id=0)
    {
        $this->load->model('Exhibition_model');
        $this->data['form_action'] = site_url('exhibition/edit/'.$id);
        $id = (int)$id;
        if (!$id) {
            redirect('exhibition');
        }
        $this->data['status_list'] = $this->Expedition_model->getStatus();
        $this->data['locales'] = $this->Exhibition_model->getLocale();
        $detail = $this->Exhibition_model->getExhibition($id);
        $post = $detail;
        if ($this->input->post()) {
            $post = $this->input->post();
            if ($this->validateForm($id)) {
                $post['uri_path'] = url_title($post['uri_path'], '-', true);
                $this->Exhibition_model->UpdateRecord($id,$post);
                $post_image = $_FILES;
                if ($post_image['primary_image']['tmp_name']) {
                    if ($detail['primary_image'] != '' && file_exists(IMG_UPLOAD_DIR.'exhibition/'.$detail['primary_image'])) {
                        unlink(IMG_UPLOAD_DIR.'exhibition/'.$detail['primary_image']);
                        unlink(IMG_UPLOAD_DIR.'exhibition/tmb_'.$detail['primary_image']);
                        unlink(IMG_UPLOAD_DIR.'exhibition/sml_'.$detail['primary_image']);
                    }
                    $filename = 'pri_'.$post['uri_path'].md5plus($id);
                    $picture_db = file_copy_to_folder($post_image['primary_image'], IMG_UPLOAD_DIR.'exhibition/', $filename);
                    copy_image_resize_to_folder(IMG_UPLOAD_DIR.'exhibition/'.$picture_db, IMG_UPLOAD_DIR.'exhibition/', 'tmb_'.$filename, IMG_THUMB_WIDTH, IMG_THUMB_HEIGHT);
                    copy_image_resize_to_folder(IMG_UPLOAD_DIR.'exhibition/'.$picture_db, IMG_UPLOAD_DIR.'exhibition/', 'sml_'.$filename, IMG_SMALL_WIDTH, IMG_SMALL_HEIGHT);

                    $this->Exhibition_model->UpdateData($id,array('primary_image'=>$picture_db));
                }
                if ($post_image['thumbnail_image']['tmp_name']) {
                    if ($detail['thumbnail_image'] != '' && file_exists(IMG_UPLOAD_DIR.'exhibition/'.$detail['thumbnail_image'])) {
                        unlink(IMG_UPLOAD_DIR.'exhibition/'.$detail['thumbnail_image']);
                        unlink(IMG_UPLOAD_DIR.'exhibition/tmb_'.$detail['thumbnail_image']);
                        unlink(IMG_UPLOAD_DIR.'exhibition/sml_'.$detail['thumbnail_image']);
                    }
                    $filename = 'thumb_'.$post['uri_path'].'_'.md5plus($id);
                    $picture_db = file_copy_to_folder($post_image['thumbnail_image'], IMG_UPLOAD_DIR.'exhibition/', $filename);
                    copy_image_resize_to_folder(IMG_UPLOAD_DIR.'exhibition/'.$picture_db, IMG_UPLOAD_DIR.'exhibition/', 'tmb_'.$filename, IMG_THUMB_WIDTH, IMG_THUMB_HEIGHT);
                    copy_image_resize_to_folder(IMG_UPLOAD_DIR.'exhibition/'.$picture_db, IMG_UPLOAD_DIR.'exhibition/', 'sml_'.$filename, IMG_SMALL_WIDTH, IMG_SMALL_HEIGHT);
                    
                    $this->Exhibition_model->UpdateData($id,array('thumbnail_image'=>$picture_db));
                }
                $this->session->set_flashdata('success_msg','Succeed.');
                
                redirect('exhibition');
            }
        }
        $this->data['post'] = $post;
        if ($this->error) {
            $this->data['message'] = alert_box($this->error,'error');
        }
    }
    
    /**
     * gallery page
     * @param int $id
     */
    public function gallery($id=0) {
        $this->load->model('Exhibition_model');
        $this->data['form_action'] = site_url('exhibition/gallery/'.$id);
        $id = (int)$id;
        if (!$id) {
            redirect('exhibition');
        }
        $this->data['cancel_url'] = site_url('exhibition');
        $this->data['list_data'] = site_url('exhibition/list_gallery/'.$id);
        $detail = $this->Exhibition_model->getExhibition($id);
        $post = $detail;
        $this->data['locales'] = $this->Exhibition_model->getLocale();
        foreach($this->data['locales'] as $locale) {
            $post['content_locale'][$locale['id_localization']] = array(
                'caption'=>'',
            );
        }
        if ($this->input->post()) {
            $post = $this->input->post();
            if ($this->validateFormGallery($id)) {
                $uri_path = $detail['uri_path'];
                $post_image = $_FILES;
                if ($post_image['image']['tmp_name']) {
                    $total_gallery = $this->Exhibition_model->countGallery($id);
                    $filename = 'gal_'.($total_gallery+1).'_'.$uri_path.md5plus($id);
                    $picture_db = file_copy_to_folder($post_image['image'], IMG_UPLOAD_DIR.'exhibition/', $filename);
                    copy_image_resize_to_folder(IMG_UPLOAD_DIR.'exhibition/'.$picture_db, IMG_UPLOAD_DIR.'exhibition/', 'tmb_'.$filename, IMG_THUMB_WIDTH, IMG_THUMB_HEIGHT);
                    copy_image_resize_to_folder(IMG_UPLOAD_DIR.'exhibition/'.$picture_db, IMG_UPLOAD_DIR.'exhibition/', 'sml_'.$filename, IMG_SMALL_WIDTH, IMG_SMALL_HEIGHT);
                    $post['id_exhibition'] = $id;
                    $post['image'] = $picture_db;
                    $id_insert = $this->Exhibition_model->InsertDataImage($post);
                    if ($id_insert) {
                        $this->session->set_flashdata('success_msg','Succeed.');
                    } else {
                        $this->session->set_flashdata('tmp_msg','Failed.');
                    }
                }
                redirect('exhibition/gallery/'.$id);
            }
        }
        $this->data['post'] = $post;
        if ($this->error) {
            $this->data['message'] = alert_box($this->error,'error');
        }
    }
    
    /**
     * list of gallery
     */
    public function list_gallery($id=0)
    {
        $alias = array();
        $query = "
            select 
                a.id_exhibition_image as id, 
                a.id_exhibition_image as idx, 
                DATE_FORMAT(CURRENT_TIMESTAMP, '%d  %b  %Y %H:%i:%S') as create_date,
                a.*,
                b.caption,
                c.locale
            from " . $this->db->dbprefix('exhibitions_image') . " a 
            left join " . $this->db->dbprefix('exhibitions_image_caption') . " b on b.id_exhibition_image=a.id_exhibition_image 
            left join " . $this->db->dbprefix('localization') . " c on c.id_localization=b.id_localization
            where a.id_exhibition='".(int)$id."' and c.locale_status=1
            ";
        $group_by = "a.id_exhibition_image";
        $this->data = query_grid($query, $alias, $group_by);
        $this->data['paging'] = paging($this->data['total']);
    }
    
    
    /**
     * slideshow page
     * @param int $id
     */
    public function slideshow($id=0) {
        $this->load->model('Exhibition_model');
        $this->data['form_action'] = site_url('exhibition/slideshow/'.$id);
        $id = (int)$id;
        if (!$id) {
            redirect('exhibition');
        }
        $this->data['cancel_url'] = site_url('exhibition');
        $this->data['list_data'] = site_url('exhibition/list_slideshow/'.$id);
        $detail = $this->Exhibition_model->getExhibition($id);
        $post = $detail;
        $this->data['locales'] = $this->Exhibition_model->getLocale();
        foreach($this->data['locales'] as $locale) {
            $post['content_locale'][$locale['id_localization']] = array(
                'caption'=>'',
            );
        }
        if ($this->input->post()) {
            $post = $this->input->post();
            if ($this->validateFormGallery($id)) {
                $uri_path = $detail['uri_path'];
                $post_image = $_FILES;
                if ($post_image['image']['tmp_name']) {
                    $total_slideshow = $this->Exhibition_model->countSlideshow($id);
                    $filename = 'slid_'.($total_slideshow+1).'_'.$uri_path.md5plus($id);
                    $picture_db = file_copy_to_folder($post_image['image'], IMG_UPLOAD_DIR.'exhibition/', $filename);
                    copy_image_resize_to_folder(IMG_UPLOAD_DIR.'exhibition/'.$picture_db, IMG_UPLOAD_DIR.'exhibition/', 'tmb_'.$filename, IMG_THUMB_WIDTH, IMG_THUMB_HEIGHT);
                    copy_image_resize_to_folder(IMG_UPLOAD_DIR.'exhibition/'.$picture_db, IMG_UPLOAD_DIR.'exhibition/', 'sml_'.$filename, IMG_SMALL_WIDTH, IMG_SMALL_HEIGHT);
                    $post['id_exhibition'] = $id;
                    $post['image'] = $picture_db;
                    $id_insert = $this->Exhibition_model->InsertDataSlideshow($post);
                    if ($id_insert) {
                        $this->session->set_flashdata('success_msg','Succeed.');
                    } else {
                        $this->session->set_flashdata('tmp_msg','Failed.');
                    }
                }
                redirect('exhibition/slideshow/'.$id);
            }
        }
        $this->data['post'] = $post;
        if ($this->error) {
            $this->data['message'] = alert_box($this->error,'error');
        }
    }
    
    /**
     * list of slideshow
     */
    public function list_slideshow($id=0)
    {
        $alias = array();
        $query = "
            select 
                a.id_exhibition_slideshow as id, 
                a.id_exhibition_slideshow as idx, 
                DATE_FORMAT(CURRENT_TIMESTAMP, '%d  %b  %Y %H:%i:%S') as create_date,
                a.*,
                b.caption,
                c.locale
            from " . $this->db->dbprefix('exhibitions_slideshow') . " a 
            left join " . $this->db->dbprefix('exhibitions_slideshow_caption') . " b on b.id_exhibition_slideshow=a.id_exhibition_slideshow 
            left join " . $this->db->dbprefix('localization') . " c on c.id_localization=b.id_localization
            where a.id_exhibition='".(int)$id."' and c.locale_status=1
            ";
        $group_by = "a.id_exhibition_slideshow";
        $this->data = query_grid($query, $alias, $group_by);
        $this->data['paging'] = paging($this->data['total']);
    }
    
    /**
     * delete record
     */
    public function delete() {
        $this->load->model('Exhibition_model');
        if (is_ajax_requested()) {
            $this->layout = 'none';
            if ($this->input->post()) {
                $id = (int)$this->input->post('iddel');
                if ($id) {
                    $detail = $this->Exhibition_model->getExhibition($id);
                    if ($detail) {
                        $this->Exhibition_model->DeleteRecord($id);
                        $this->session->set_flashdata('success_msg','Data has been deleted.');
                    } else {
                        $this->session->set_flashdata('message','There is no record in our database.');
                    }
                }
            }
        } else {
            redirect('exhibition');
        }
    }
    
    /**
     * delete gallery record
     */
    public function delete_gallery() {
        $this->load->model('Exhibition_model');
        if (is_ajax_requested()) {
            $this->layout = 'none';
            if ($this->input->post()) {
                $id = (int)$this->input->post('iddel');
                if ($id) {
                    $detail = $this->Exhibition_model->getExhibitionGallery($id);
                    if ($detail) {
                        $this->Exhibition_model->DeleteRecordGallery($id);
                        $this->session->set_flashdata('success_msg','Data has been deleted.');
                    } else {
                        $this->session->set_flashdata('message','There is no record in our database.');
                    }
                }
            }
        } else {
            redirect('exhibition');
        }
    }

    /**
     * delete slideshow record
     */
    public function delete_slideshow() {
        $this->load->model('Exhibition_model');
        if (is_ajax_requested()) {
            $this->layout = 'none';
            if ($this->input->post()) {
                $id = (int)$this->input->post('iddel');
                if ($id) {
                    $detail = $this->Exhibition_model->getExhibitionSlideshow($id);
                    if ($detail) {
                        $this->Exhibition_model->DeleteRecordSlideshow($id);
                        $this->session->set_flashdata('success_msg','Data has been deleted.');
                    } else {
                        $this->session->set_flashdata('message','There is no record in our database.');
                    }
                }
            }
        } else {
            redirect('exhibition');
        }
    }

    /**
     * form validation
     * @param int $id
     * @return boolean true/false
     */
    private function validateForm($id=0) {
        $id = (int)$id;
        $this->load->model('Exhibition_model');
        $locales = $this->Exhibition_model->getLocaleDefault();
        $post = $this->input->post();
        $post['uri_path'] = url_title($post['uri_path'], '-', true);
        $err = '';
        /*if ($post['alias'] =='') {
            $err .= 'Please insert Exhibition Title.<br/>';
        }*/
        foreach($post['content_locale'] as $row => $val) {
            if ($row == $locales['id_localization'] && $val['title'] == '') {
                $err .= 'Please insert Content Title.<br/>';
            }
        }
        if (empty($post['content_locale']) || count($post['content_locale']) == 0) {
            $err .= 'Please insert Exhibition Content.<br/>';
        }
        if ($post['uri_path'] == '') {
            $err .= 'Please insert SEO Link.<br/>';
        } else {
            if (!$this->Exhibition_model->check_exists_path($post['uri_path'],$id)) {
                $err .= 'SEO Link already used.<br/>';
            }
        }
        $post_image = $_FILES;
        if (!empty($post_image['primary_image']['tmp_name'])) {
            $check_picture = validatePicture('primary_image');
            if (!empty($check_picture)) {
                $err .= $check_picture.'<br/>';
            }
        }
        if (!empty($post_image['thumbnail_image']['tmp_name'])) {
            $check_picture = validatePicture('thumbnail_image');
            if (!empty($check_picture)) {
                $err .= $check_picture.'<br/>';
            }
        }
        
        if ($err) {
            $this->error = $err;
            return false;
        } else {
            return true;
        }
    }
    
    /**
     * validate gallery form
     * @param int $id
     * @return boolean
     */
    private function validateFormGallery($id=0) {
        $id = (int)$id;
        $post = $this->input->post();
        $post_file = $_FILES;
        $err = '';
        if (!$id) {
            redirect('exhibition');
        }
        if ($post_file['image']['tmp_name'] =='') {
            $err .= 'Please insert Image.<br/>';
        } else {
            $check_picture = validatePicture('image');
            if (!empty($check_picture)) {
                $err .= $check_picture.'<br/>';
            }
        }
        
        if ($err) {
            $this->error = $err;
            return false;
        } else {
            return true;
        }
    }

}
/* End of file exhibition.php */
/* Location: ./application/controllers/exhibition.php */