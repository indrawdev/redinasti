<link href="<?= CSS_URL ?>bootstrap-fileupload.min.css" rel="stylesheet"/>
<script language="JavaScript" src="<?= JS_URL ?>bootstrap-fileupload.min.js"></script>
<script language="JavaScript" src="<?= JS_URL ?>jquery.alphanumeric.pack.js"></script>
<section class="well animated fadeInUp">
    <div class="row-fluid">
        <div class="span12">
            <div style='float: left;color: #00a429'>
                <ul class="breadcrumb">
                </ul>
            </div>
            <div style="clear:both;"></div>
            <?php if (isset($message)) { ?>
                <div style='float: left;color: #00a429'><?= $message ?></div>
            <?php } ?>
            <?php if (isset($tmp_msg)) { ?>
                <div style='float: left;color: #00a429'><?= $tmp_msg ?></div>
            <?php } ?>
            <?php if (isset($success_msg)) { ?>
                <div style='float: left;color: #00a429'><?= $success_msg ?></div>
            <?php } ?>
        </div>
    </div>  
    <hr/>
    <!-- start form -->
    <form action="<?= $form_action ?>" method="post" enctype="multipart/form-data"  class="well">
        <div class="row-fluid">
            <div class="span8">
                <fieldset>
                    <legend>Content</legend>
                    <?php if ($locales) { ?>
                    <div class="tabbable">
                        <ul class="nav nav-tabs">
                            <?php 
                                $a=0;
                                foreach ($locales as $locale) { 
                                    $default = '';
                                    if ($locale['locale_status'] == 1) {
                                        $default = ' (default)';
                                    }
                                    if ($a==0) {
                                        echo '<li class="active"><a href="#'.$locale['iso_2'].'-'.$locale['id_localization'].'" data-toggle="tab">'.ucfirst($locale['locale']).$default.'</a></li>';
                                    } else {
                                        echo '<li><a href="#'.$locale['iso_2'].'-'.$locale['id_localization'].'" data-toggle="tab">'.ucfirst($locale['locale']).$default.'</a></li>';
                                    }
                                    $a++;
                                }
                            ?>
                        </ul>
                        <div class="tab-content">
                            <?php 
                                $a=0;
                                foreach ($locales as $locale) { 
                                    if ($a==0) {
                                        echo '<div class="tab-pane active" id="'.$locale['iso_2'].'-'.$locale['id_localization'].'">';
                                    } else {
                                        echo '<div class="tab-pane" id="'.$locale['iso_2'].'-'.$locale['id_localization'].'">';
                                    }
                                    $a++;
                                    echo '<div class="row-fluid">';
                                    echo '<div class="span12">';
                                    echo '<label for="description">Caption ('.ucfirst($locale['locale']).')</label>';
                                    echo '<textarea id="description" rows="10" class="input-block-level " name="content_locale['.$locale['id_localization'].'][caption]" style="resize: none">'.$post['content_locale'][$locale['id_localization']]['caption'].'</textarea>';
                                    echo '</div>';
                                    echo '</div>';
                                    
                                    echo '</div>';
                                }
                            ?>
                        </div>
                    </div>
                    <?php } ?>
                </fieldset>
            </div>
            <div class="span4">
                <!-- start media -->
                <fieldset>
                    <legend>Image</legend>
                    <div class="row-fluid">
                        <div class="span12">
                            <label for="primary_image">Image</label>
                            <div class="fileupload fileupload-new" data-provides="fileupload">
                                <div class="fileupload-new thumbnail" style="width: 200px; height: 150px;">
                                    <img src=""/>
                                </div>
                                <div class="fileupload-preview fileupload-exists thumbnail" style="max-width: 200px; max-height: 150px; line-height: 20px;">
                                    
                                </div>
                                <div>
                                    <span class="btn btn-file">
                                        <span class="fileupload-new">Select image</span>
                                        <span class="fileupload-exists">Change</span>
                                        <input name="image" id="image" type="file" />
                                    </span>
                                    <a href="#" class="btn fileupload-exists" data-dismiss="fileupload">Remove</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </fieldset>
                <!-- end of media -->
            </div>
        </div>
        <hr/>
        <div class="row-fluid">
            <div class="span6">
                &nbsp;
            </div>
            <div class="span6 text-right">
                <button class="btn btn-primary" type="submit"><i class="icon-save"></i> Upload</button>
                <a class="btn btn-warning" href="<?=site_url('category')?>"><i class="icon-ban-circle"></i> Cancel</a>
            </div>
        </div>
    </form>
    <!-- end of form -->
    <hr/>
    <div id='list_grid'>
        <button type="button" class="btn reload" title='Reload Data'><i class="icon-refresh"></i></button>
        <select class='perpage' style='margin-bottom:0;width:125px;'>
            <optgroup label='Show per page'>
                <option value='5'>5</option>
                <option value='10'>10</option>
                <option value='50'>50</option>
                <option value='100'>100</option>
            </optgroup>
        </select>
        <?php
            if (isset($error_msg)) {
                echo $error_msg;
            }
        ?>
        <!-- start listing data -->
        <table class="table table-striped table-bordered table-hover">
            <thead>
                <tr>
                    <th class="center" style='width:1px;'>No</th>
                    <th class="center">Image <span></span></th>
                    <th class="center">Caption <span></span></th>
                    <th class="center">Created <span></span></th>
                    <th class="center">Action</th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
        <!-- end of listing data -->
        <hr/>
    </div>
</section>
<style>
    .ui-icon-carat-1-s,.ui-icon-carat-1-n{float: right;}
</style>
<script>
    the_grid('list_grid', '<?= $list_data ?>', 10);
</script>