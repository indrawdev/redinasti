<link href="<?= CSS_URL ?>bootstrap-fileupload.min.css" rel="stylesheet"/>
<script language="JavaScript" src="<?= JS_URL ?>bootstrap-fileupload.min.js"></script>
<script language="JavaScript" src="<?= JS_URL ?>jquery.alphanumeric.pack.js"></script>
<section class="well animated fadeInUp">
    <h3><i class="icon-plus-sign text-success"></i> Add New Product</h3>
    <hr/>
    <?php 
        if (isset($message)) { 
            echo $message;
        }
    ?>
    <form action="<?= $form_action ?>" method="post" enctype="multipart/form-data"  class="well">
        <div class="row-fluid">
            <div class="span8">
                <div class="tabbable">
                    <ul class="nav nav-tabs">
                        <li class="active"><a href="#tcontent" data-toggle="tab">Content</a></li>
                        <li><a href="#ttechnology" data-toggle="tab">Technology</a></li>
                        <li><a href="#toutlet" data-toggle="tab">Outlet</a></li>
                    </ul>
                    
                    <div class="tab-content">
                        <!-- content form tab -->
                        <div class="tab-pane active" id="tcontent">
                            <fieldset>
                                <legend>Content</legend>
                                <div class="row-fluid">
                                    <div class="span12">
                                        <label for="product_name">Product Name</label>
                                        <input type="text" id="product_name" class="input-block-level" name="product_name" value="<?=$post['product_name']?>"/>
                                    </div>
                                </div>
                                <div class="row-fluid">
                                    <div class="span12">
                                        <label class="option" for="id_category">Category</label>
                                        <select class="perpage" name="id_category" id="id_category">
                                            <?php
                                                foreach($categories as $category) {
                                                    if (isset($post['id_category']) && $post['id_category'] == $category['id_category']) {
                                                        echo '<option value="'.$category['id_category'].'" selected="selected">'.$category['title'].'</option>';
                                                    } else {
                                                        echo '<option value="'.$category['id_category'].'">'.$category['title'].'</option>';
                                                    }
                                                }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="row-fluid">
                                    <div class="span12">
                                        <label class="option" for="id_product_tags">Type</label>
                                        <select class="perpage" name="id_product_tags" id="id_product_tags">
                                            <?php
                                                foreach($tags as $tag) {
                                                    if (isset($post['id_product_tags']) && $post['id_product_tags'] == $tag['id_product_tags']) {
                                                        echo '<option value="'.$tag['id_product_tags'].'" selected="selected">'.$tag['tags'].'</option>';
                                                    } else {
                                                        echo '<option value="'.$tag['id_product_tags'].'">'.$tag['tags'].'</option>';
                                                    }
                                                }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <br/>
                                <?php if ($locales) { ?>
                                <div class="tabbable">
                                    <ul class="nav nav-tabs">
                                        <?php 
                                            $a=0;
                                            foreach ($locales as $locale) { 
                                                $default = '';
                                                if ($locale['locale_status'] == 1) {
                                                    $default = ' (default)';
                                                }
                                                if ($a==0) {
                                                    echo '<li class="active"><a href="#'.$locale['iso_2'].'-'.$locale['id_localization'].'" data-toggle="tab">'.ucfirst($locale['locale']).$default.'</a></li>';
                                                } else {
                                                    echo '<li><a href="#'.$locale['iso_2'].'-'.$locale['id_localization'].'" data-toggle="tab">'.ucfirst($locale['locale']).$default.'</a></li>';
                                                }
                                                $a++;
                                            }
                                        ?>
                                    </ul>
                                    <div class="tab-content">
                                        <?php 
                                            $a=0;
                                            foreach ($locales as $locale) { 
                                                if ($a==0) {
                                                    echo '<div class="tab-pane active" id="'.$locale['iso_2'].'-'.$locale['id_localization'].'">';
                                                } else {
                                                    echo '<div class="tab-pane" id="'.$locale['iso_2'].'-'.$locale['id_localization'].'">';
                                                }
                                                $a++;

                                                echo '<div class="row-fluid">';
                                                echo '<div class="span12">';
                                                echo '<label for="teaser">Teaser ('.ucfirst($locale['locale']).')</label>';
                                                echo '<textarea id="teaser" rows="4" class="input-block-level" name="content_locale['.$locale['id_localization'].'][teaser]" style="resize: none">'.$post['content_locale'][$locale['id_localization']]['teaser'].'</textarea>';
                                                echo '</div>';
                                                echo '</div>';

                                                echo '<div class="row-fluid">';
                                                echo '<div class="span12">';
                                                echo '<label for="description">Description ('.ucfirst($locale['locale']).')</label>';
                                                echo '<textarea id="description" rows="10" class="input-block-level ckeditor" name="content_locale['.$locale['id_localization'].'][description]" style="resize: none">'.$post['content_locale'][$locale['id_localization']]['description'].'</textarea>';
                                                echo '</div>';
                                                echo '</div>';

                                                echo '<div class="row-fluid" style="margin-top:25px;">';
                                                echo '<div class="span12">';
                                                echo '<label for="spesification">Spesification ('.ucfirst($locale['locale']).')</label>';
                                                echo '<textarea id="spesification" rows="10" class="input-block-level ckeditor" name="content_locale['.$locale['id_localization'].'][spesification]" style="resize: none">'.$post['content_locale'][$locale['id_localization']]['spesification'].'</textarea>';
                                                echo '</div>';
                                                echo '</div>';

                                                echo '</div>';
                                            }
                                        ?>
                                    </div>
                                </div>
                                <?php } ?>
                            </fieldset>
                        </div><!-- content form tab -->
                        
                        <!-- technology form tab -->
                        <div class="tab-pane" id="ttechnology">
                            <fieldset>
                                <legend>Technology</legend>
                                <div class="row-fluid">
                                    <div class="span12">
                                        <?php
                                            if ($technologies) {
                                                foreach ($technologies as $techno) {
                                                    echo '<label class="checkbox" style="margin-top: 8px;">';
                                                    if (!empty($post['technology'][$techno['id_technology']]['id_technology']) && ($post['technology'][$techno['id_technology']]['id_technology'] == $techno['id_technology'])) {
                                                        echo '<input type="checkbox" name="technology['.$techno['id_technology'].'][id_technology]" value="1" checked/> '.$techno['title'];
                                                    } else {
                                                        echo '<input type="checkbox" name="technology['.$techno['id_technology'].'][id_technology]" value="1"/> '.$techno['title'];
                                                    }
                                                    echo '</label>';
                                                }
                                            }
                                        ?>
                                    </div>
                                </div>
                            </fieldset>
                        </div><!-- technology form tab -->
                        
                        <!-- outlet form tab -->
                        <div class="tab-pane" id="ttechnology">
                            <fieldset>
                                <legend>Outlet</legend>
                                <div class="row-fluid">
                                    <div class="span12">
                                        <?php
                                            if ($outlets) {
                                                foreach ($outlets as $outlet) {
                                                    echo '<label class="checkbox" style="margin-top: 8px;">';
                                                    if (!empty($post['outlet'][$outlet['id_outlet']]['id_outlet']) && ($post['outlet'][$outlet['id_outlet']]['id_outlet'] == $outlet['id_outlet'])) {
                                                        echo '<input type="checkbox" name="outlet['.$outlet['id_outlet'].'][id_technology]" value="'.$outlet['id_outlet'].'" checked/> '.$outlet['outlet'].' ('.$outlet['country'].')';
                                                    } else {
                                                        echo '<input type="checkbox" name="outlet['.$outlet['id_outlet'].'][id_technology]" value="'.$outlet['id_outlet'].'"/> '.$outlet['outlet'].' ('.$outlet['country'].')';
                                                    }
                                                    echo '</label>';
                                                }
                                            }
                                        ?>
                                    </div>
                                </div>
                            </fieldset>
                        </div><!-- outlet form tab -->
                    </div>
                </div>
            </div>
            <div class="span4">
                <!-- start publishing option -->
                <fieldset>
                    <legend>Publishing Options</legend>
                    <div class="row-fluid">
                        <div class="span12">
                            <label for="seo">SEO Link <i class="icon-question-sign text-info pop" title="Leave this field empty if you want the seo link the same as  menu title" data-placement="bottom" data-toggle="tooltip"></i></label>
                            <input type="text" id="seo" class="input-block-level" name="uri_path" value="<?=$post['uri_path']?>"/>
                        </div>
                    </div>
                    <div class="row-fluid">
                        <div class="span12">
                            <label for="startPublish">Publish Date</label>
                            <div id="startPublish" class="input-prepend">
                                <span class="add-on curp">
                                    <i data-time-icon="icon-time" data-date-icon="icon-calendar" class="icon-calendar">
                                    </i>
                                </span>
                                <input data-format="yyyy-mm-dd" type="text" class="span11 pop-datepicker" name="publish_date" value="<?=$post['publish_date']?>" placeholder="yyyy-mm-dd" readonly="readonly"/>
                            </div>
                        </div>
                    </div>
                    <div class="row-fluid">
                        <div class="span12">
                            <label class="option" for="status">Publish</label>
                            <select class="perpage" name="id_status" id="status">
                                <?php
                                    foreach($status_list as $status) {
                                        if (isset($post['id_status']) && $post['id_status'] == $status['id_status']) {
                                            echo '<option value="'.$status['id_status'].'" selected="selected">'.$status['status_text'].'</option>';
                                        } else {
                                            echo '<option value="'.$status['id_status'].'">'.$status['status_text'].'</option>';
                                        }
                                    }
                                ?>
                            </select>
                        </div>
                    </div>
                    <?php 
                    /** disabled featured status
                    <div class="row-fluid">
                        <div class="span12">
                            <label class="checkbox" style="margin-top: 8px;">
                                <?php if (!empty($post['is_featured'])) { ?>
                                <input type="checkbox" name="is_featured" value="1" checked/> Featured
                                <?php } else { ?>
                                <input type="checkbox" name="is_featured" value="1"/> Featured
                                <?php } ?>
                            </label>
                        </div>
                    </div>
                     * 
                     */
                    ?>
                    <div class="row-fluid">
                        <div class="span12">
                            <label class="checkbox" style="margin-top: 8px;">
                                <?php if (!empty($post['is_hikeholic'])) { ?>
                                <input type="checkbox" name="is_hikeholic" value="1" checked/> HikeHolic
                                <?php } else { ?>
                                <input type="checkbox" name="is_hikeholic" value="1"/> HikeHolic
                                <?php } ?>
                            </label>
                        </div>
                    </div>
                    <div class="row-fluid">
                        <div class="span12">
                            <label class="checkbox" style="margin-top: 8px;">
                                <?php if (!empty($post['is_new'])) { ?>
                                <input type="checkbox" name="is_new" value="1" checked/> New
                                <?php } else { ?>
                                <input type="checkbox" name="is_new" value="1"/> New
                                <?php } ?>
                            </label>
                        </div>
                    </div>
                </fieldset>
                <hr/>
                <!-- end of publishing option -->
                <!-- start media -->
                <fieldset>
                    <legend>Media</legend>
                    <div class="row-fluid">
                        <div class="span12">
                            <label for="primary_image">Primary Image</label>
                            <div class="fileupload fileupload-new" data-provides="fileupload">
                                <div class="fileupload-new thumbnail" style="width: 200px; height: 150px;">
                                    <img src="" />
                                </div>
                                <div class="fileupload-preview fileupload-exists thumbnail" style="max-width: 200px; max-height: 150px; line-height: 20px;">
                                    
                                </div>
                                <div>
                                    <span class="btn btn-file">
                                        <span class="fileupload-new">Select image</span>
                                        <span class="fileupload-exists">Change</span>
                                        <input name="primary_image" id="primary_image" type="file" />
                                    </span>
                                    <a href="#" class="btn fileupload-exists" data-dismiss="fileupload">Remove</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row-fluid" style="margin-top:30px;">
                        <div class="span12">
                            <label for="thumbnail_image">Thumbnail Image</label>
                            <div class="fileupload fileupload-new" data-provides="fileupload">
                                <div class="fileupload-new thumbnail" style="width: 200px; height: 150px;">
                                    <img src="" />
                                </div>
                                <div class="fileupload-preview fileupload-exists thumbnail" style="max-width: 200px; max-height: 150px; line-height: 20px;">
                                    
                                </div>
                                <div>
                                    <span class="btn btn-file">
                                        <span class="fileupload-new">Select image</span>
                                        <span class="fileupload-exists">Change</span>
                                        <input name="thumbnail_image" id="thumbnail_image" type="file" />
                                    </span>
                                    <a href="#" class="btn fileupload-exists" data-dismiss="fileupload">Remove</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </fieldset>
                <hr/>
                <!-- end of media -->
            </div>
        </div>
        <hr/>
        <div class="row-fluid">
            <div class="span6">
                &nbsp;
            </div>
            <div class="span6 text-right">
                <button class="btn btn-primary" type="submit"><i class="icon-save"></i> Save</button>
                <a class="btn btn-warning" href="<?=site_url('product')?>"><i class="icon-ban-circle"></i> Cancel</a>
            </div>
        </div>
    </form>
</section>
<script type="text/javascript">
    $("#product_name").keyup(function() {
        $("#seo").val(convert_to_uri(this.value));
    });
</script>
