/**
 * custom script
 * @author ivan lubis
 * @version 2.0
 */

function convert_to_uri(val)
{
    return val
        .toLowerCase()
        .replace(/ /g,'-')
        .replace(/[^\w-]+/g,'')
        ;
}

// include jquery
$(window).load(function() {
});

$(document).scroll(function() {
    if ($(document).scrollTop() >= 500) {
        $('.floatNav').css({
            height: 195,
            transition: '0.6s'
        }, 100);
    } else {
        $('.floatNav').css({
            top: 0,
            transition: '0.6s'
        }, 100);
    }
});

$(document).ready(function() {

    $('#mainSlide').height($(window).height() - 65).carousel({
        interval: 5000
    });
    $('#mainSlide .carousel-inner, #mainSlide .carousel-inner .item').height($(window).height() - 65);
    $('.exhibition, .expedition').height($(window).height() - 65);

    $('#lineupSlide').height($(window).height() - 65).carousel({
        interval: false
    });
    $('#productDetailCarousel').carousel({
        interval: false
    });
    $('.productSidebar').mouseover(function() {
        $(this).addClass('active').mouseout(function() {
            $(this).removeClass('active');
        });
    });

    var width = 0;
    $('.technoGallery li').each(function() {
        width += $(this).outerWidth(true);
    });
    $('.technoGallery ul').css('width', width);


    $('.expedition, .exhibition').mouseover(function() {
        $(this).find('.backdrop').css('opacity', '0');
        $(this).removeClass('idle').mouseout(function() {
            $(this).addClass('idle').find('.backdrop').css('opacity', '1');
        });
    });


    $('.pictureGallery .item').mouseover(function() {

        $(this).find('.desc').addClass('show').mouseout(function() {
            $(this).removeClass('show');
        });
    });

    $('body.find-eiger').backstretch(assets_url + 'img/lineupBg.jpg');
    $('body.news-event, body.news-event-detail').backstretch(assets_url + 'img/newseventBg.jpg');
    $('body.expedition-list').backstretch(assets_url + 'img/expeditionListBg.jpg');
    $('body.exhibition-list').backstretch(assets_url + 'img/exhibitionListBg.jpg');
    $('body.partners-list').backstretch(assets_url + 'img/exhibitionListBg.jpg');
    $('.exhibition').backstretch(assets_url + 'img/exhibitionBg.jpg');
    $('.expedition').backstretch(assets_url + 'img/expeditionBg.jpg');
    $('body.manufacture').backstretch(assets_url + 'img/manufacture.jpg');
    $('body.business').backstretch(assets_url + 'img/businessBg.jpg');
    $('body.contact').backstretch(assets_url + 'img/contactBg.jpg');
    $('body.technology').backstretch(assets_url + 'img/technoBg.jpg');

    var minHeights = $(window).height();
    $('.lineUp-container, .accordion-lineUp ul').width($(window).width()).height($(window).height() - 60)
    $('.accordion-lineUp .item').height($(window).height() - 60).css({
        minHeight: minHeights
    });
    /*$('.accordion-lineUp .item.peak').backstretch(assets_url+'img/lineUp/peak.jpg');
     $('.accordion-lineUp .item.path').backstretch(assets_url+'img/lineUp/path.jpg');
     $('.accordion-lineUp .item.tour').backstretch(assets_url+'img/lineUp/tour.jpg');
     $('.accordion-lineUp .item.trail').backstretch(assets_url+'img/lineUp/trail.jpg');
     $('.accordion-lineUp .item.ride').backstretch(assets_url+'img/lineUp/ride.jpg');
     $('.accordion-lineUp .item.daily').backstretch(assets_url+'img/lineUp/daily.jpg');*/


    $('#modal-gallery').on('load', function() {
        var modalData = $(this).data('modal');
    });

    $('#expedexhibDetail .carousel-inner').width($('#expedexhibDetail').width() + 60);
    $('.pictureGallery .title').width($('.pictureGallery').width() + 60);
    $('ul#filters').width($('.container').width());
    $(function()
    {
        $('.scroll-pane').jScrollPane({
            mouseWheelSpeed: 20
        });

        $('.horizon.scroll-pane').jScrollPane({
            mouseWheelSpeed: 20
        });
    });

    $('.main-container').queryLoader2({
        barColor: "#6e6d73",
        backgroundColor: "#000",
        percentage: true,
        barHeight: 0,
        deepSearch: true,
        completeAnimation: "fade",
        onLoadComplete: function() {
            $('#loaderImage').css('display', 'none');
            setTimeout(function() {
                jQuery('body.home a#navToggle').trigger('click');
            }, 1000);

        },
        minimumTime: 100
    });

    $('#slideToggle').click(function() {
        $('.slideTogglebox').slideToggle();
    });


    $('.nav-toggle').click(function() {
        var collapse_content_selector = $(this).attr('href');

        var toggle_switch = $(this);
        $(collapse_content_selector).toggle(function() {
            if ($(this).css('display') == 'none') {
                toggle_switch.html('Show');
            } else {
                toggle_switch.html('Hide');
            }
        });
    });
    $('.thumbNavigation li').each(function() {
        $(this).mouseover(function() {
            $(this).addClass('active');
        });
        $(this).mouseout(function() {
            $(this).removeClass('active');
        });

    });
    $('a#navToggle').click(function(event) {
        value = $(this).parent().parent().css('height') === '195px' ? 490 : '195px';
        $(this).parent().parent().animate({
            height: value
        }, 500);

    });

    /**
    $('.type1 .draggingButton, .type3 .draggingButton').each(function() {
        $(this).click(function(event) {
            value = $(this).parent().children().children('.drag-content').css('right') === '-300px' ? 0 : '-300px';
            $(this).parent().children().children('.drag-content').animate({
                right: value
            });

        });

    });
    */

    $('#mainSlide .type1 .draggingButton, #mainSlide .type2 .draggingButton,#mainSlide .type3 .draggingButton').click(function(e) {
        e.preventDefault();
        // minimize tagging
        //$(this).parent().toggleClass('hiding');
    });




    /*$('.type2 .draggingButton').each(function() {
        $(this).click(function(event) {
            value = $(this).parent().children().children('.drag-content').css('right') === '-330px' ? -5 : '-330px';
            $(this).parent().children().children('.drag-content').animate({
                right: value
            });
        });
    });
    */

    $('.tagging .draggingButton').each(function() {
        $(this).click(function(event) {
            value = $(this).parent().children().children('.drag-content').css('right') === '-330px' ? -5 : '-330px';
            $(this).parent().children().children('.drag-content').animate({
                right: value
            });
        });

    });

    $('.tagging .draggingButton').click(function(e) {
        e.preventDefault();
        $(this).parent().toggleClass('hideTag');
    });


    $('.share').mouseover(function() {
        $(this).children('ul').addClass('show').mouseout(function() {
            $(this).removeClass('show');
        });
        $(this).mouseout(function() {
            $(this).children('ul').removeClass('show');
        });
    });

    $('.hasSubmenu').each(function() {
        $(this).mouseover(function() {
            $(this).children().children('ul').addClass('show').mouseout(function() {
                $(this).removeClass('show');
            });
            $(this).children().children('.showCase').addClass('show').mouseout(function() {
                $(this).removeClass('show');
            });
        });
        $(this).mouseout(function() {
            $(this).children().children('ul').removeClass('show');
            $(this).children().children('.showCase').removeClass('show');
        });
    });
    $('.sliding').mouseover(function() {
        $('.hasSubmenu .inner').css('visibility', 'visible');
    });
    $('.sliding').mouseout(function() {
        $('.hasSubmenu .inner').css('visibility', 'hidden');
    });

    $('.lineUp .item').mouseover(function() {
        $(this).addClass('active')
    });
    $('.lineUp .item').mouseout(function() {
        $(this).removeClass('active')
    });
    $(function() {
        var $container = $('#containerLocation');

        $container.isotope({
            itemSelector: '.element'
        });
        var $optionSets = $('#options .option-set'),
                $optionLinks = $optionSets.find('a');

        $optionLinks.click(function() {
            var $this = $(this);
            if ($this.hasClass('selected')) {
                return false;
            }
            var $optionSet = $this.parents('.option-set');
            $optionSet.find('.selected').removeClass('selected');
            $this.addClass('selected');
            var options = {},
                    key = $optionSet.attr('data-option-key'),
                    value = $this.attr('data-option-value');
            value = value === 'false' ? false : value;
            options[ key ] = value;
            if (key === 'layoutMode' && typeof changeLayoutMode === 'function') {
                changeLayoutMode($this, options)
            } else {
                $container.isotope(options);
            }

            return false;
        });


    });
    $('#customDropdown').ddslick({
        onSelected: function(selectedData) {
        }
    });
    $('a.viewMap').each(function() {
        $(this).click(function() {
            $('a.viewMap').removeClass('active').parent().find('.mapLocation').removeClass('show');
            var self = this
            setTimeout(function() {
                $(self).addClass('active').parent().find('.mapLocation').addClass('show');
                $('a.close').css('opacity', '1');
            }, 1000);
        });

        var mapWidth = $('.locationMap').width();
        $('.mapLocation').css({
            minWidth: mapWidth
        });


        $('a.close, #filters li a').click(function() {
            $('.mapLocation').removeClass('show');
            $('.viewMap').removeClass('active');
            $('a.close').css('opacity', '0');
        });
    });

    /*$('a.show').click(function(){
     $(this).addClass('active').parent().parent().find('.mapLocation').addClass('show');
     });*/
    // hide #back-top first
    $("#back-top").hide();

    // fade in #back-top
    $(function() {
        $(window).scroll(function() {
            if ($(this).scrollTop() > 100) {
                //$('#back-top').fadeIn();
            } else {
                //$('#back-top').fadeOut();
            }
        });

        // scroll body to 0px on click
        $('#back-top a').click(function() {
            $('body,html').animate({
                scrollTop: 0
            }, 800);
            return false;
        });
    });

    //$('.accordion-lineUp li').each(function(){
    $('.accordion-lineUp li').mouseover(function() {
        $('.accordion-lineUp li').addClass('inactive').removeClass('active')
        $(this).addClass('active');

    });
    $('.accordion-lineUp ul').mouseout(function() {
        $(this).children('li').removeClass('inactive').removeClass('active')
    });



    //	});
});

$(window).scroll(function() {
    if ($(window).scrollTop() + $(window).height() > $(document).height() - 100) {
        $('body.footThumb .thumbNavigation').css('bottom', '0px');
        $('#back-top').fadeIn();
    } else {
        $('body.footThumb .thumbNavigation').css('bottom', '-70px');
        $('#back-top').fadeOut();
    }
});

$(window).resize(function() {
    $('#mainSlide').height($(window).height() - 65);
    $('.technoList.innerContent').height($(window).height() - 220);
    $('.newsList.innerContent').height($(window).height() - 220);
    $('.exhibition, .expedition').height($(window).height() - 65);
    $('.lineUp-container').width($(window).width()).height($(window).height());
    $('.accordion-lineUp .item').height($(window).height());
});

$(window).trigger('resize');

// buat drag tagging tapi untuk front end disable dulu
$('.draggingButton').parent('.dragging').drags();

